param (
    [Parameter(Mandatory = $true)]
    [string]$LogMessage
)
# define folder path
$botFolderPath = (Resolve-Path "..\..\").Path
$confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
$configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
$configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
$logFolderPath = Join-Path -Path $botFolderPath -ChildPath "log"

# get data from the json file
$configFile = Get-content -Path $configFilePath |  ConvertFrom-Json

# define log output file path
$logFilePath = Join-Path -Path $logFolderPath -ChildPath $configFile.logFileName

try {
    $time = Get-Date -Format "MM-dd-yyyy - HH:mm:ss"
    Add-Content -Path $logFilePath -Value "$time -- $LogMessage"
}
catch {
    Write-Output "Error While Writing Log File $_"
}