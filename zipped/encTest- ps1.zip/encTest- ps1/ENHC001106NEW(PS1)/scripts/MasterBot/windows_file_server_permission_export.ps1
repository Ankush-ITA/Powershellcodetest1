# Define folder paths
$botFolderPath = (Resolve-Path "..\..\").Path
$confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
$configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
$configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
$credsFolderPath = Join-Path -Path $confFolderPath -ChildPath "Creds"
$licenseFolderPath = Join-Path -Path $confFolderPath -ChildPath "License"
$inputFolderPath = Join-Path -Path $botFolderPath -ChildPath "input"
$outputFolderPath = Join-Path -Path $botFolderPath -ChildPath "output"
$scriptsFolderPath = Join-Path -Path $botFolderPath -ChildPath "scripts"
$microbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MicroBots"

# get data from config file
$configFile = Get-content -Path $configFilePath |  ConvertFrom-Json

# Import the CredentialManager module
Import-Module CredentialManager

# Import microbots
try {
    $LogEntry = Join-Path -Path $microbotFolderPath -ChildPath "logentry.exe"
    $SendEmail =  Join-Path -Path $microbotFolderPath -ChildPath "sendemail.exe"
}
catch {
    Write-Output "ERROR - While Importing Required MicroBots"
}



# Decrypting keys and checking license
function decryptkey {
    param (
        [string]$filePath
    )

    [Byte[]] $uniqueKey = (5, 7, 82, 19, 252, 25, 7, 88, 19, 253, 11, 254, 3, 10, 15, 20)
    $output = Get-Content $filePath -Raw | ConvertTo-SecureString -Key $uniqueKey
    $decryptedText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($output))
    return $decryptedText
}

$secretkeyFIlePath = Join-Path -Path $credsFolderPath -ChildPath "secretkey.txt"
$vectorkeyFilePath = Join-Path -Path $credsFolderPath -ChildPath "vectorkey.txt"
$licenseFilePath = Join-Path -Path $licenseFolderPath -ChildPath "license.txt"

$secretKey = decryptkey -filePath $secretkeyFIlePath
$vectorKey = decryptkey -filePath $vectorkeyFilePath
$currentDate = Get-Date
$encryptionKey = [System.Text.Encoding]::UTF8.GetBytes($secretKey)
$ivBytes = [System.Text.Encoding]::UTF8.GetBytes($vectorKey)
$encryptedLicenseInfo = Get-Content -Path $licenseFilePath -Encoding Byte

try {
    $decryptedLicenseInfo = [System.Security.Cryptography.Aes]::Create() | ForEach-Object {
        $_.Key = $encryptionKey
        $_.IV = $ivBytes
        $_.Mode = [System.Security.Cryptography.CipherMode]::CBC
        $_.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $_.CreateDecryptor().TransformFinalBlock($encryptedLicenseInfo, 0, $encryptedLicenseInfo.Length)
    }

    if ($decryptedLicenseInfo) {
        $decryptedLicenseInfo = [System.Text.Encoding]::UTF8.GetString($decryptedLicenseInfo)
        $licenseData = $decryptedLicenseInfo | ConvertFrom-Json

        if ([DateTime]::Parse($licenseData.StartDate) -le $currentDate -and [DateTime]::Parse($licenseData.ExpiryDate) -ge $currentDate) {
            $daysRemaining = [math]::Ceiling(([DateTime]::Parse($licenseData.ExpiryDate) - $currentDate ).Totaldays)
            & $LogEntry -LogMessage "SUCCESS - License Validation Complete!! Valid From: $(Get-Date $licenseData.StartDate -Format "dd-MMM-yyyy"); Until: $(Get-Date $licenseData.ExpiryDate -Format "dd-MMM-yyyy"); Remaining Days: $daysRemaining"
        } elseif ([DateTime]::Parse($licenseData.StartDate) -lt $currentDate) {
        }
    } else {
        & $LogEntry -LogMessage "ERROR - License Expired!!"
        exit
    }
} catch {
    & $LogEntry -LogMessage "ERROR -  While Loading License File!!"
    exit
}

# Load configurations from config file
$configFile = Get-content -Path $configFilePath | ConvertFrom-Json

# Fetch server details from input file
$logFilePath = Join-Path -Path $outputFolderPath -ChildPath "FailureRecords.csv"
$logMessages = @()

try {
    $serverNames = Get-Content -Path (Join-Path -Path $inputFolderPath -ChildPath "servers.txt")
    $allPermissions = @()

    foreach ($server in $serverNames) {
        if (Test-Connection -ComputerName $server -Count 1 -Quiet) {
            Write-Output "Server: $server is reachable, Hence proceeding for Authentication"
            & $LogEntry -LogMessage "Server: $server is reachable, Hence proceeding for Authentication"
            try{
            $Credential = Get-StoredCredential -Target "ServerDetails"
            }catch{
            & $LogEntry -LogMessage "Server: Failed to access ServerDetails from StoredCredentials"
            }
            $session = New-PSSession -ComputerName $server -Credential $Credential

            if ($session) {
                Write-Host "Authenticated to $server"
                & $LogEntry -LogMessage "Successfully Authenticated to the $server"

                # Check if shared folders exist
                $sharedFoldersExist = Invoke-Command -Session $session -ScriptBlock {
                    Get-SmbShare -ErrorAction SilentlyContinue
                }

                if ($sharedFoldersExist) {
                    # Fetch shared folders
                    $sharedFoldersOutput = Invoke-Command -Session $session -ScriptBlock {
                        Get-SmbShare | Select-Object Name, Path
                    }
                    $sharedFolders = $sharedFoldersOutput | ForEach-Object {
                        [PSCustomObject]@{
                            Server = $server
                            Name = $_.Name
                            Path = $_.Path
                        }
                    }

                    if ($sharedFolders) {
                        foreach ($folder in $sharedFolders) {
                            if (-not [string]::IsNullOrWhiteSpace($folder.Path)) {
                                # Get the ACL (Access Control List) for the specified folder path
                                $acl = Invoke-Command -Session $session -ScriptBlock {
                                    Get-Acl -Path $using:folder.Path
                                }

                                # Extract the owner and group names from the ACL
                                $owner = $acl.Owner
                                $group = $acl.Group

                                # Fetch permissions
                                $permissionsOutput = Invoke-Command -Session $session -ScriptBlock {
                                    Get-Acl -Path $using:folder.Path | Select-Object -ExpandProperty Access
                                }

                                $permissions = $permissionsOutput | ForEach-Object {
                                    [PSCustomObject]@{
                                        Owner = $owner
                                        Group = $group
                                        Identity = $_.IdentityReference
                                        FileSystemRights = $_.FileSystemRights
                                        AccessControlType = $_.AccessControlType
                                    }
                                }

                                if ($permissions) {
                                    $allPermissions += $permissions | Select-Object @{
                                        Name='Server'; Expression={$folder.Server}
                                    }, @{
                                        Name='FolderName'; Expression={$folder.Name}
                                    }, *
                                    & $LogEntry -LogMessage "Successfully fetched the permissions for $($folder.Name) on $($folder.Server)"
                                } else {
                                    $logMessages += "Failed to fetch permissions for $($folder.Name) on $($folder.Server)"
                                    & $LogEntry -LogMessage "Failed to fetch permissions for $($folder.Name) on $($folder.Server)"
                                }
                            } else {
                                $logMessages += "Path not found for $($folder.Name) on $($folder.Server)"
                                & $LogEntry -LogMessage "Path not found for $($folder.Name) on $($folder.Server)"
                            }
                        }
                    } else {
                        $logMessages += "No shared folders found on $server"
                        & $LogEntry -LogMessage "No shared folders found on $server"
                    }
                } else {
                    $logMessages += "No shared folders found on $server"
                    & $LogEntry -LogMessage "No shared folders found on $server"
                }

                Remove-PSSession -Session $session -ErrorAction SilentlyContinue
            } else {
                $logMessages += "Authentication failed for $server"
                Write-Output "Authentication failed for $server"
                & $LogEntry -LogMessage "Authentication failed for $server"
            }
        } else {
            $logMessages += "$server is not reachable"
            Write-Output "Server: $Server is not reachable"
            & $LogEntry -LogMessage "Server: $Server is not reachable"
        }
    }

    # Save all permissions to a single CSV file
    $outputFilePath = Join-Path -Path $outputFolderPath -ChildPath "$($configFile.outputFileName).csv"
    $allPermissions | Export-Csv -Path $outputFilePath -NoTypeInformation -Force

    # Write logs to output file
    $logMessages | Out-File -FilePath $logFilePath -Force

    # Sending email
    $emailBody = "Hi, This is a system generated message please IGNORE"
    $attachmentArray = @()

    if (Test-Path $outputFilePath) {
        $attachmentArray += $outputFilePath
    }

    if ($logMessages.Count -gt 0) {
        $attachmentArray += $logFilePath
    }

    if ($attachmentArray.Count -gt 0) {
        & $SendEmail -EmailBody $emailBody -Attachment $attachmentArray
    } else {
        Write-Output "No attachments found. Email will not be sent."
        & $LogEntry -LogMessage "ERROR - No attachments found. Email will not be sent."
    }

    Write-Host "Script execution completed"
} catch {
    $errorMessage = "Error in Master-Bot: $_"
    Write-Error $errorMessage
    $errorMessage | Out-File -FilePath $logFilePath -Force
}
