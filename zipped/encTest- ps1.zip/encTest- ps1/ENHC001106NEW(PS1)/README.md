# ENHC0011063_Windows_File_Server_Permission_Export_PowerShell

## Description

## Pre-Requisite
- Jump Server 
- BOT should be copied to Jump Server (sftp.capgemini.com should be allowed to access from Jump Server )
- If required specific ports need to be enabled in firewall to respective servers (rare requirement)
- PowerShell (Version: 5.1.19041.3570; Edition: Desktop)
- You need  enter the Administrator Credentials to run this script
- Update config.json file with appropriate data specific to the client
- If bot needs to be scheduled to run automatically, account/cleint should provide service account with credentials (Credential - never expire password)

## High-Level Logic
- The script begins by decrypting the necessary credential files for accessing servers
- It checks the validity of a license file to ensure compliance with usage requirements
- The script collects license details of organization
- After collecting the license details it will store the report as .csv/.txt/.html file in output folder

## MicroBOT
- The logentry.exe tool is used to record detailed logs and maintain transparency throughout the compliance checking process
- This appends Windows_File_Server_Permission_Export.log in logs folder

## Routines
- **Decrypt Credential File**: The script decrypts credential files
- **License Validation**: Validates the license file to ensure authorized usage
- **Collect Server Information**: 
- **Log and Error Handling**: Logs detailed information using MicroBOT and handles exceptions

## Input Parameters
- Not Aplicable / Applicable

## Output
- After execution, this bot generates a .csv/.txt/.html file in the "\output" directory
- After execution, this bot also generates the log file "\log" directory

## License
- Ensure you have a valid license file in the specified directory to run the script
- If license expired please reach out to CREATE development POD for renewal till client contract end date

## Dependencies
- Below files must be on "conf" directory
- license.txt (can be obtained from CREATE program for validity according to Client agreement)
- secretkey.txt
- vectorkey.txt