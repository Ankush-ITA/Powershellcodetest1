param (
    [Parameter(Mandatory = $true)]
    [string]$EmailBody,

    [Parameter(Mandatory = $true)]
    [string[]]$Attachment
)

# define folder path
$botFolderPath = (Resolve-Path "..\..\").Path
$confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
$configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
$configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
$scriptsFolderPath = Join-Path -Path $botFolderPath -ChildPath "scripts"
$microbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MicroBots"

# define essential microbot
try {
    $LogEntry = Join-Path -Path $microbotFolderPath -ChildPath "logentry.ps1"
}
catch {
    Write-Output "ERROR - While Importing Essential MicroBots"
}

# get data from the json file
$configFile = Get-content -Path $configFilePath |  ConvertFrom-Json

# sending email with body-as-html
if (($configFile.emailRequired.ToLower() -eq "yes") -and ($configFile.emailBodyAsHTMLRequired.ToLower() -eq "yes")) {
    try {
        $emailBody = Get-Content -Path $Attachment -Raw
        $credential = New-Object System.Management.Automation.PSCredential -ArgumentList (Get-StoredCredential -Target $($configFile.emailCredential)).UserName, (Get-StoredCredential -Target $($configFile.emailCredential)).Password
        Send-MailMessage -SmtpServer $($configFile.smtpServer) -Port $($configFile.smtpPort) -UseSsl -From $((Get-StoredCredential -Target $($configFile.emailCredential)).UserName) -To $($configFile.toMail) -Subject $($configFile.subjectMail) -Body $EmailBody -BodyAsHtml -Credential $credential
        & $LogEntry -LogMessage "SUCCESS -  Mail Sent Successfully To: $($configFile.toMail)"
    }
    catch {
        & $LogEntry -LogMessage "ERROR - Mail Sent Unsuccessful"
    }
}
# sending email without bosy-as-html
elseif (($configFile.emailRequired.ToLower() -eq "yes") -and ($configFile.emailBodyAsHTMLRequired.ToLower() -eq "no")) {
    try {
        $credential = New-Object System.Management.Automation.PSCredential -ArgumentList (Get-StoredCredential -Target $($configFile.emailCredential)).UserName, (Get-StoredCredential -Target $($configFile.emailCredential)).Password
        Send-MailMessage -SmtpServer $($configFile.smtpServer) -Port $($configFile.smtpPort) -UseSsl -From $((Get-StoredCredential -Target $($configFile.emailCredential)).UserName) -To $($configFile.toMail) -Subject $($configFile.subjectMail) -Body $EmailBody -Credential $credential -Attachments $Attachment
        & $LogEntry -LogMessage "SUCCESS -  Mail Sent Successfully To: $($configFile.toMail)"
    }
    catch {
        & $LogEntry -LogMessage "ERROR - Mail Sent Unsuccessful"
    }
}
# mail configuration not defined
else {
    & $LogEntry -LogMessage "ERROR - Mail Configuration Not Done Properly, Check config File"
}