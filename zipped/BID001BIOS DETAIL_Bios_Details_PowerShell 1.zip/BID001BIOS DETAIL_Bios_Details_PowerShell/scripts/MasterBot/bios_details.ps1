# define folder path
$botFolderPath = (Resolve-Path "..\..\").Path
$confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
$configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
$configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
$credsFolderPath = Join-Path -Path $confFolderPath -ChildPath "Creds"
$licenseFolderPath = Join-Path -Path $confFolderPath -ChildPath "License"
$inputFolderPath = Join-Path -Path $botFolderPath -ChildPath "input"
$outputFolderPath = Join-Path -Path $botFolderPath -ChildPath "output"
$scriptsFolderPath = Join-Path -Path $botFolderPath -ChildPath "scripts"
$microbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MicroBots"

# get data from config file
$configFile = Get-content -Path $configFilePath |  ConvertFrom-Json

# define essential microbot
try {
    $LogEntry = Join-Path -Path $microbotFolderPath -ChildPath "logentry.exe"
    $SendEmail =  Join-Path -Path $microbotFolderPath -ChildPath "sendemail.exe"
}
catch {
    Write-Output "ERROR - While Importing Required MicroBots"
}

# define all the key file
$secretkeyFIlePath = Join-Path -Path $credsFolderPath -ChildPath "secretkey.txt"
$vectorkeyFilePath = Join-Path -Path $credsFolderPath -ChildPath "vectorkey.txt"
$licenseFilePath = Join-Path -Path $licenseFolderPath -ChildPath "license.txt"

############################### Do Not Change Anything Below ###############################
# decrypting key and password
function decryptkey {
    param (
        [string]$filePath
    )
    [Byte[]] $uniqueKey = (5, 7, 82, 19, 252, 25, 7, 88, 19, 253, 11, 254, 3, 10, 15, 20)
    $output = Get-Content $filePath -Raw | ConvertTo-SecureString -Key $uniqueKey
    $decryptedText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($output))
    return $decryptedText
}

# checking License
$secretKey = decryptkey -filePath $secretkeyFIlePath
$vectorKey = decryptkey -filePath $vectorkeyFilePath
$currentDate = Get-Date
$encryptionKey = [System.Text.Encoding]::UTF8.GetBytes($secretKey)
$ivBytes = [System.Text.Encoding]::UTF8.GetBytes($vectorKey)
$encryptedLicenseInfo = Get-Content -Path $licenseFilePath -Encoding Byte
$decryptedLicenseInfo = $null
try {
    $decryptedLicenseInfo = [System.Security.Cryptography.Aes]::Create() | ForEach-Object {
        $_.Key = $encryptionKey
        $_.IV = $ivBytes
        $_.Mode = [System.Security.Cryptography.CipherMode]::CBC  # Use CBC mode
        $_.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $_.CreateDecryptor().TransformFinalBlock($encryptedLicenseInfo, 0, $encryptedLicenseInfo.Length)
    }
    if ($decryptedLicenseInfo) {
        $decryptedLicenseInfo = [System.Text.Encoding]::UTF8.GetString($decryptedLicenseInfo)
        $licenseData = $decryptedLicenseInfo | ConvertFrom-Json
        if ([DateTime]::Parse($licenseData.StartDate) -le $currentDate -and [DateTime]::Parse($licenseData.ExpiryDate) -ge $currentDate) {
            $daysRemaining = [math]::Ceiling(([DateTime]::Parse($licenseData.ExpiryDate) - $currentDate ).Totaldays)
            & $LogEntry -LogMessage "SUCCESS - License Validation Complete!! Valid From: $(Get-Date $licenseData.StartDate -Format "dd-MMM-yyyy"); Until: $(Get-Date $licenseData.ExpiryDate -Format "dd-MMM-yyyy"); Remaining Days: $daysRemaining"
        }
        elseif ([DateTime]::Parse($licenseData.StartDate) -lt $currentDate) {
        }
    }
    else {
        & $LogEntry -LogMessage "ERROR - License Expired!!"
        exit
    }
}
catch {
    & $LogEntry -LogMessage "ERROR -  While Loading License File!!"
    exit
}
############################### Do Not Change Anything Above ###############################

# importing MicroBot
<#try {
    . "MICROBOT_FILE_PATH"
}
catch {
    Write-Output "ERROR - While Importing MicroBots"
    & $LogEntry -LogMessage "ERROR - MicroBots Not Found!!"
}#>
############################### Do Not Change Anything Above ###############################

# Get the server list file path
$serverListPath = Join-Path -Path $inputFolderPath -ChildPath "Servers.txt"
 
# Define the output file path
$outputFilePath = Join-Path -Path $outputFolderPath -ChildPath "out.csv"
 
try {
    # Check if the output file is present
    if (!(Test-Path -Path $outputFilePath)) {
        # Log a message if the output file is not present
        & $LogEntry -LogMessage "ERROR - Output File Not Present"
    } else {
        # Execute the command
        Get-WmiObject -Class Win32_BIOS -ComputerName (Get-Content $serverListPath) | Select-Object PSComputerName, Description, SMBIOSBIOSVersion, SerialNumber, ProductNumber, Version | Export-Csv -Path $outputFilePath -NoTypeInformation
    }
} catch {
    # Log the error using your bot's logging function
    & $LogEntry -LogMessage "ERROR - An error occurred at $(Get-Date): $_"
}
 

##############################################################################################
# sending email
$emailBody = "Hi, This is system generated message please IGNORE"
$outputFilePath = Join-Path $outputFolderPath -ChildPath $configFile.outputFileName
# checking if the file is present or not
if (Test-Path $outputFilePath) {
    & $SendEmail -EmailBody $emailBody -Attachment $outputFilePath
}
else {
    & $LogEntry -LogMessage "ERROR - Output File Not Present"
}