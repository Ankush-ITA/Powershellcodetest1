## ENHC0010625_Get_Folder_Size_PowerShell

    ## Description


    ## Pre-Requisite
    - PowerShell (Version: 5.1.19041.3570; Edition: Desktop)
    - If BOT will be run from the windows Schedule, then Service Account should be created with required permissions and password.
    - Service Account creation is Account Scope.
    - Before starting the bot, update the config file: targetName, smtpServer, smtpPort, toMail, fromMail.


    ## High-Level Logic


    ## MicroBOT


    ## Routines
    - **Decrypt Credential File**: The script decrypts credential files for secure server access.
    - **License Validation**: Validates the license file to ensure authorized usage.
    - **Log and Error Handling**: Logs detailed information using MicroBOT and handles exceptions.

    ## config.json
    - All BoT realted configuration to be updated here.
    - Like Email ID, SMTP Server Name, Server PORT Address, Inputfile Name, Outfile Name, Mail Subject etc..
    
    ## Input Parameters
    - Before execution, this bot also need input parameters configured in "ENHC0010625_Get_Folder_Size_PowerShell\input" directory.

    ## Output
    - After execution, this bot also generates the log file "ENHC0010625_Get_Folder_Size_PowerShell\log" directory.

    ## License
    - Ensure you have a valid license file in the specified directory to run the script.
    - If License Expired please reach out to CREATE Development PoD.
    
    ## Note
    - BoT executable should be copied to the jump server.
    - Check permissions to access Jump servers and perform patch compliance checks.

    ## Dependencies
    - Below files must be present in the respective directory
    - ENHC0010625_Get_Folder_Size_PowerShell\conf\License\license.txt (can be obtained from CREATE program for validity according to Client agreement)
    - ENHC0010625_Get_Folder_Size_PowerShell\conf\Creds\secretkey.txt
    - ENHC0010625_Get_Folder_Size_PowerShell\conf\Creds\vectorkey.txt