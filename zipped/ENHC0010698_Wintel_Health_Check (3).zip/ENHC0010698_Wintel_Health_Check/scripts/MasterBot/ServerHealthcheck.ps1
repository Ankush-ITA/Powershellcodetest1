########################################################################################
# Creating folder path constant 
########################################################################################
$botFolderPath = (Resolve-Path "..\..").Path
$confFolderPath = Join-Path -Path $botFolderPath -ChildPath "conf"
$configFolderPath = Join-Path -Path $confFolderPath -ChildPath "Config"
$configFilePath = Join-Path -Path $configFolderPath -ChildPath "config.json"
$credsFolderPath = Join-Path -Path $confFolderPath -ChildPath "Creds"
$licenseFolderPath = Join-Path -Path $confFolderPath -ChildPath "License"
$inputFolderPath = Join-Path -Path $botFolderPath -ChildPath "input"
$outputFolderPath = Join-Path -Path $botFolderPath -ChildPath "output"
$logFolderPath = Join-Path -Path $botFolderPath -ChildPath "log"
$scriptsFolderPath = Join-Path -Path $botFolderPath -ChildPath "scripts"
$masterbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MasterBot"
$microbotFolderPath = Join-Path -Path $scriptsFolderPath -ChildPath "MicroBots"

# Get path for output file
$csvoutputfile = Join-Path -Path $outputFolderPath -ChildPath "/output.csv"

# Get data from config.json file
$configFile = Get-content -Path $configFilePath |  ConvertFrom-Json

# Define log microbot
$logEntryMicroBotFilePath = Join-Path -Path $microbotFolderPath -ChildPath "logentry.exe"
$logcnt = Get-Content -Path $logEntryMicroBotFilePath -Raw




$LogFilePath = Join-Path -Path $logFolderPath -ChildPath "/logentry1.txt"

# Define key and license file path
$secretkeyFIlePath = Join-Path -Path $credsFolderPath -ChildPath "secretkey.txt"
$vectorkeyFilePath = Join-Path -Path $credsFolderPath -ChildPath "vectorkey.txt"
$licenseFilePath = Join-Path -Path $licenseFolderPath -ChildPath "license.txt"

# Output file destination
$outputLogFilePath = Join-Path -Path $logFolderPath -ChildPath $configFile.logFileName

# Service Account target name from credential manager
$targetName = $configFile.TargetName

# Credential of Service Account
$userName = (Get-StoredCredential -Target "$targetName").UserName
$password = (Get-StoredCredential -Target "$targetName").Password

########################################################################################
#################### Decrypting key and password ####################
########################################################################################

 function decryptkey {
    param (
        [string]$filePath
    )
    [Byte[]] $uniqueKey = (5, 7, 82, 19, 252, 25, 7, 88, 19, 253, 11, 254, 3, 10, 15, 20)
    $output = Get-Content $filePath -Raw | ConvertTo-SecureString -Key $uniqueKey
    $decryptedText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($output))
    return $decryptedText
}

########################################################################################
#################### Checking License ####################
########################################################################################
$secretKey = decryptkey -filePath $secretkeyFilePath
$vectorKey = decryptkey -filePath $vectorkeyFilePath
#$emailPassword = decryptkey -filePath $emailPasswordFilePath

$global:currentDate = Get-Date
$encryptionKey = [System.Text.Encoding]::UTF8.GetBytes($secretKey)
$ivBytes = [System.Text.Encoding]::UTF8.GetBytes($vectorKey)
# Decrypt and Validate License from the file
$encryptedLicenseInfo = Get-Content -Path $licenseFilePath -Encoding Byte
$decryptedLicenseInfo = $null
try {
    $decryptedLicenseInfo = [System.Security.Cryptography.Aes]::Create() | ForEach-Object {
        $_.Key = $encryptionKey
        $_.IV = $ivBytes
        $_.Mode = [System.Security.Cryptography.CipherMode]::CBC  # Use CBC mode
        $_.Padding = [System.Security.Cryptography.PaddingMode]::PKCS7
        $_.CreateDecryptor().TransformFinalBlock($encryptedLicenseInfo, 0, $encryptedLicenseInfo.Length)
    }
    if ($decryptedLicenseInfo) {
        $decryptedLicenseInfo = [System.Text.Encoding]::UTF8.GetString($decryptedLicenseInfo)
        $licenseData = $decryptedLicenseInfo | ConvertFrom-Json
        if ([DateTime]::Parse($licenseData.StartDate) -le $global:currentDate -and [DateTime]::Parse($licenseData.ExpiryDate) -ge $currentDate) { 
            $global:daysRemaining = [math]::Ceiling(([DateTime]::Parse($licenseData.ExpiryDate) - $global:currentDate ).Totaldays)
            Write-Host "Days Remaining: $daysRemaining"
            & $logEntryMicroBotFilePath "SUCCESS - License Validation Complete!! Valid From: $($licenseData.StartDate) Valid Until: $($licenseData.ExpiryDate)" -LogFile $outputLogFilePath
        }
        elseif ([DateTime]::Parse($licenseData.StartDate) -lt $global:currentDate) {
        }
    }

    else {
        Write-Host "License has expired."
        & $logEntryMicroBotFilePath "ERROR - License Expired!!" -LogFile $outputLogFilePath
        exit
    }
}
     
catch {
    Write-Host "An error occurred while decrypting the license: $_append"
    & $logEntryMicroBotFilePath "ERROR -  While Loading License File!!" -LogFile $outputLogFilePath
    exit
}


########################################################################################
#################### MasterBot ####################
########################################################################################
try{
    ## Get the server names from input file
    $serverNames = Join-Path -Path $botFolderPath -ChildPath "\input\servernames.txt"

    ##Server Name details
    $Server_name = Get-Content -Path $serverNames
    $output = @{}
    
    & $logEntryMicroBotFilePath "SUCCESS - Get Content From Input File" -LogFile $LogFilePath
}

catch{
    Write-Output "Error: $_"
    & $logEntryMicroBotFilePath "ERROR - Missing Input File" -LogFile $LogFilePath
}  




# Check if there are any servers
if ($Server_name -eq $null) {
    Write-Host "No servers found in the file."
    & $LogEntryBot "No servers found in the file." -LogFile $LogFilePath
    exit
}

$totalServers = $Server_name.Count
Write-Host "Total number of servers: $totalServers"

try{
        
    #Removing the old output file
    $ErrorActionPreference = "SilentlyContinue"
    Remove-Item -Path $csvoutputfile 
   


    foreach ($server in $Server_name) 
    { 
        $folder_size1 = $folder_size
    
        ## Connect to server
        if (Test-Connection -ComputerName $server -Count 1 -Quiet)
        {
            Write-Output "Server: $server is reachable, Hence proceeding for Authentication"
            & $logEntryMicroBotFilePath "Server: $server is reachable, Hence proceeding for Authentication " -LogFile $LogFilePath
    
            #Fetching credentials and starting the session
            $credential = New-Object System.Management.Automation.PSCredential ($userName, $password)
            $session = New-PSSession -ComputerName $server -Credential $credential
            
            
            $result = Invoke-Command -Session $session -ScriptBlock {
    
                param(
    
                [array]$server
                
            
                )
                
################################# CPU Utilization #################################

                $CPUutilization = Get-WmiObject -ComputerName $server Win32_Processor | Measure-Object -property LoadPercentage -Average | Select-Object Average
               
################################# Memory Utilization #################################

                $memoryusage = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $server  | Select-Object @{Name = "MemoryUsage"; Expression = { "{0:N2}" -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory) * 100) / $_.TotalVisibleMemorySize) } }
                $totalmemory = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $server | Select-Object @{Name = "ToTalMemory_inGB"; Expression = { "{0:N2}" -f ($_.TotalVisibleMemorySize /1MB) } } 

################################# C Drive Utilization #################################  
              
                $disks = ((Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='C:'" -ComputerName $server).Size / 1GB)
                $CDriveUtilization =  (Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='C:'" -ComputerName $server ).FreeSpace / (Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='C:'" -ComputerName $server).Size * 100      
                
################################# Uptime #################################

                function WMIDateStringToDate($bootup) {
                    [System.Management.ManagementDateTimeconverter]::ToDateTime($bootup)
                 }
                 $nameSpace = "Root\CIMV2"
                 $wmi = [WMISearcher]""
                   $wmi.options.timeout = '0:0:15' #set timeout to 30 seconds
                   $query = 'Select * from Win32_OperatingSystem'
                   $wmi.scope.path = "\\$server\$NameSpace"
  
                 $wmi.query = $query
                 try{
                     $wmiResult = $wmi.Get()
                     #$wmiResult
                     foreach ($wmiOutput in $wmiResult){
                        $bootup = $wmiOutput.LastBootUpTime
                        $lastBootUpTime = WMIDateStringToDate($bootup)
                        $now = Get-Date
                        $reportTime = $now - $lastBootUpTime
                        $d = $reportTime.Days
                        $h = $reportTime.Hours
                        $m = $reportTime.Minutes
                   
                        $a = "Up for: {0} days, {1} hours, {2:N0} minutes" -f $d,$h,$m
                        
                     }
                 }
                 catch [Exception] {
                     Write-Host "Error while fetching Uptime"
                     
                 }

################################# Automatic Service Status #################################

                #region Ignore 	
            		$ignore = @( 
            		    'Microsoft .NET Framework NGEN v4.0.30319_X64', 
            		    'Microsoft .NET Framework NGEN v4.0.30319_X86', 
            		    'Performance Logs and Alerts', 
            		    'Shell Hardware Detection', 
            		    'Software Protection'; 
            		)
            	#endregione
            	
            	try {
            		$autoServices = Get-WmiObject -Namespace 'root\cimv2' -Class Win32_Service -ComputerName $server -ErrorAction Stop | Where-Object {$_.StartMode -eq 'Auto' -and $ignore -notcontains $_.DisplayName } | ForEach-Object {$_.Displayname}  # | FT Displayname -HideTableHeaders | Out-String  -Stream
            		$servicestatus = Get-WmiObject -Namespace 'root\cimv2' -Class Win32_Service -ComputerName $server -ErrorAction Stop | Where-Object {$_.StartMode -eq 'Auto' -and $ignore -notcontains $_.DisplayName } | ForEach-Object { $_.State}  # | FT Displayname -HideTableHeaders | Out-String  -Stream
                    if ($null -ne $autoServices){  #Implement $? last error checking pending 
            			#foreach ($service in $autoServices) {
                        #foreach ($state in $servicestatus) 
                        for ($i = 0; $i -lt $autoServices.Count; $i++) 
                        {
                        $service = $autoServices[$i]
                        $state = $servicestatus[$i]
                        
            			$totalFailedNew += "$service : $state"
            			$totalFailedNew += " `n` "
                        
            			}
                
                        }
            		
            		else{
            			$totalFailedNew = "OK"
            		}
            		
            	}
            	Catch {
                	Write-Host "Error while fetching Automatic Service Status"
            	}  
           
             $output += [PSCustomObject] @{
                      
                    Server       =  "$server"
                    CPULoad      =  "$($CPUutilization.Average)%"
                    ToTalMemory_inGB = "$($totalmemory.ToTalMemory_inGB)"
                    Memory_Usage_Utilization  =  "$($memoryusage.MemoryUsage)%"
                    C_Drive_Total_Memory_inGB = "$disks"
                    C_Drive_Utilization       =  "$($CDriveUtilization)%"
                    Uptime       =  "$a"
                    Automatic_Service_Status      =  "$totalFailedNew "
                    
                
                }
            
                return $output

            }  -ArgumentList $server
            
            $result  | Out-File -FilePath "$csvoutputfile" -Append 
                    
          

            & $logEntryMicroBotFilePath "All the details fetched successfully." -LogFile $LogFilePath

        }
   
        else {
        
            Write-Output "Unable to connect to the server"
            & $logEntryMicroBotFilePath "Server: $server is not reachable " -LogFile $LogFilePath

            if($configFile.emailRequired -eq "Y"){
                Write-host " Server connection failure mail Sent Successfully. "
                Send-MailMessage -SmtpServer $jsonConfig.smtpServer -From $jsonConfig.fromMail -To $configFile.toMail -Subject $jsonConfig.subject -Body "Unable to connect to $server" -Port $jsonConfig.smtpPort
                & $logEntryMicroBotFilePath "Mail sent successfully." -LogFile $LogFilePath
            }
            }
    }
     
    # Remove the PSSession
    Remove-PSSession $session
}

catch
{
    Write-Host "Error while fetching the details."
    & $logEntryMicroBotFilePath "Error while fetching the details." -LogFile $LogFilePath
    
    if($configFile.emailRequired -eq "Y"){
        Write-host " Mail Sent Successfully. "
        Send-MailMessage -SmtpServer $jsonConfig.smtpServer -From $jsonConfig.fromMail -To $configFile.toMail -Subject $jsonConfig.subject -Body "Error while fetching the details." -Port $jsonConfig.smtpPort 
        & $logEntryMicroBotFilePath "Mail sent successfully." -LogFile $LogFilePath

    }
}

  
try 
{
    if($configFile.emailRequired -eq "Y"){
    Send-MailMessage -SmtpServer $jsonConfig.smtpServer -From $jsonConfig.fromMail -To $configFile.toMail -Subject $jsonConfig.subject -Body "Unable to connect to $server" -Port $jsonConfig.smtpPort -Attachments "$csvoutputfile"
    Write-Host "Mail sent successfully."
    & $logEntryMicroBotFilePath "Mail sent successfully with the output file attachment." -LogFile $LogFilePath
    }
}

catch
{

    Write-Output "Unable to send the mail."
    #& $logEntryMicroBotFilePath "Unable to send the mail." -LogFile $LogFilePath

}